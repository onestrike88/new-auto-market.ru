import { Metadata } from 'next'
import CreditCalculator from '@/components/credit-calculator'
import CreditHero from '@/components/credit-hero'
import BankPartners from '@/components/bank-partners'
import CreditBenefits from '@/components/credit-benefits'
import SpecialCreditOffers from '@/components/special-credit-offers'
import CreditForm from '@/components/credit-form'

export const metadata: Metadata = {
  title: 'Автокредит | ДЦ Орехово',
  description: 'Выгодные условия автокредитования от ведущих банков в ДЦ Орехово. Ставка от 3.9%, одобрение за 30 минут.',
}

export default function CreditPage() {
  return (
    <div className="bg-white">
      <CreditHero />
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <CreditCalculator />
          <CreditForm />
        </div>
        <CreditBenefits />
        <SpecialCreditOffers />
        <BankPartners />
      </div>
    </div>
  )
}

