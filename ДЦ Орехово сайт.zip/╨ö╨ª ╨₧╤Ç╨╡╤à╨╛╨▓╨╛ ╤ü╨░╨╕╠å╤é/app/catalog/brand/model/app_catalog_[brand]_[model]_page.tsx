import { notFound } from 'next/navigation'
import CarModelPage from '@/components/car-model-page'
import { cars } from '@/data/cars'

export default function CarPage({ params }: { params: { brand: string, model: string } }) {
  const car = cars.find(c => c.brand.toLowerCase() === params.brand.toLowerCase() && c.model.toLowerCase() === params.model.toLowerCase())

  if (!car) {
    notFound()
  }

  const otherModels = cars.filter(c => c.brand === car.brand && c.model !== car.model).map(c => ({
    name: c.model,
    image: c.image,
    availableCount: Math.floor(Math.random() * 10) + 1, // Random number for demo purposes
    price: c.price,
    monthlyPayment: Math.round(c.price / 60), // Simple calculation, adjust as needed
  }))

  return (
    <CarModelPage
      brand={car.brand}
      model={car.model}
      color={car.color}
      price={car.price}
      discount={295000} // This should be dynamic based on your business logic
      monthlyPayment={Math.round(car.price / 60)} // This is a simple calculation, adjust as needed
      images={[car.image, car.image, car.image, car.image]} // You should have multiple images for each car
      specifications={{
        'Год выпуска': car.year,
        'Двигатель': car.engine,
        'Коробка передач': car.transmission,
        'Привод': car.drivetrain,
        'Тип топлива': car.fuelType,
        'Тип кузова': car.bodyType,
        'Цвет': car.color,
      }}
      configurations={[
        {
          name: 'Luxury',
          engine: car.engine,
          transmission: car.transmission,
          drivetrain: car.drivetrain,
          price: car.price,
        },
        {
          name: 'Honor',
          engine: car.engine,
          transmission: car.transmission,
          drivetrain: car.drivetrain,
          price: car.price * 1.1, // 10% more expensive for demo purposes
        },
      ]}
      otherModels={otherModels}
    />
  )
}

