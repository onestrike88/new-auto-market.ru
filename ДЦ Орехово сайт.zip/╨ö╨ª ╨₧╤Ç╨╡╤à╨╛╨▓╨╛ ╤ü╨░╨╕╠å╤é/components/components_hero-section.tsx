'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import Image from 'next/image'

const slides = [
  {
    badge: "Ограниченное предложение",
    title: "Ваш идеальный автомобиль ждет вас!",
    subtitle: "Эксклюзивные предложения с выгодой до 500 000 ₽",
    buttonText: "Найти свой автомобиль",
    image: "https://via.placeholder.com/1200x600",
    link: "/catalog"
  },
  {
    badge: "Ограниченное предложение",
    title: "Кредит от 3.9% на все модели",
    subtitle: "Одобрение за 15 минут, первый платеж через 3 месяца",
    buttonText: "Рассчитать выгоду",
    image: "https://via.placeholder.com/1200x600",
    link: "/credit"
  },
  {
    badge: "Ограниченное предложение",
    title: "Тест-драйв в день обращения",
    subtitle: "Испытайте автомобиль в реальных условиях уже сегодня",
    buttonText: "Записаться на тест-драйв",
    image: "https://via.placeholder.com/1200x600",
    link: "/test-drive"
  }
]

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <section className="relative h-[600px] overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-500 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="absolute inset-0">
            <Image
              src={slide.image}
              alt={slide.title}
              layout="fill"
              objectFit="cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50" />
          </div>
          <div className="relative h-full max-w-[1300px] mx-auto px-4 py-12 flex flex-col justify-center">
            <Badge variant="secondary" className="w-fit mb-4">
              {slide.badge}
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 max-w-2xl">
              {slide.title}
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-2xl">
              {slide.subtitle}
            </p>
            <Link href={slide.link}>
              <Button 
                variant="secondary" 
                size="lg" 
              >
                {slide.buttonText}
              </Button>
            </Link>
          </div>
        </div>
      ))}

      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
        aria-label="Previous slide"
      >
        <ChevronLeft className="h-6 w-6 text-white" />
      </button>

      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors"
        aria-label="Next slide"
      >
        <ChevronRight className="h-6 w-6 text-white" />
      </button>
    </section>
  )
}

