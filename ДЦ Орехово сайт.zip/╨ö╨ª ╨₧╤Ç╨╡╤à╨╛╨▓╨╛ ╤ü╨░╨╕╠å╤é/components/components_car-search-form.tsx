'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from '@/components/ui/input'
import { cars, Car } from '@/data/cars'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import Image from 'next/image'
import Link from 'next/link'
import { Search } from 'lucide-react'

export const CarSearchForm = () => {
  const [brand, setBrand] = useState('')
  const [model, setModel] = useState('')
  const [maxPrice, setMaxPrice] = useState('')
  const [bodyType, setBodyType] = useState('')
  const [transmission, setTransmission] = useState('')
  const [drivetrain, setDrivetrain] = useState('')
  const [filteredCars, setFilteredCars] = useState<Car[]>([])
  const [availableModels, setAvailableModels] = useState<string[]>([])

  const uniqueBrands = Array.from(new Set(cars.map(car => car.brand)))
  const uniqueBodyTypes = Array.from(new Set(cars.map(car => car.bodyType)))
  const uniqueTransmissions = Array.from(new Set(cars.map(car => car.transmission)))

  const handleBrandChange = (selectedBrand: string) => {
    setBrand(selectedBrand)
    const filteredModels = Array.from(new Set(cars
      .filter(car => car.brand === selectedBrand)
      .map(car => car.model)))
    setAvailableModels(filteredModels)
    setModel('')
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const filtered = cars.filter(car => 
      (!brand || car.brand === brand) &&
      (!model || car.model === model) &&
      (!maxPrice || car.price <= parseInt(maxPrice)) &&
      (!bodyType || bodyType === 'all' || car.bodyType.toLowerCase() === bodyType.toLowerCase()) &&
      (!transmission || transmission === 'all' || car.transmission.toLowerCase() === transmission.toLowerCase()) &&
      (!drivetrain || drivetrain === 'all' || car.drivetrain.toLowerCase() === drivetrain.toLowerCase())
    )
    setFilteredCars(filtered)
  }

  return (
    <section className="bg-white py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6 text-center">Найдите идеальный автомобиль</h2>
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Параметры поиска</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select onValueChange={handleBrandChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Марка" />
                  </SelectTrigger>
                  <SelectContent>
                    {uniqueBrands.map(brand => (
                      <SelectItem key={brand} value={brand}>{brand}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select onValueChange={setModel} value={model}>
                  <SelectTrigger>
                    <SelectValue placeholder="Модель" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableModels.map(model => (
                      <SelectItem key={model} value={model}>{model}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="number"
                  placeholder="Максимальная цена"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Select onValueChange={setBodyType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Тип кузова" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все</SelectItem>
                    <SelectItem value="sedan">Седан</SelectItem>
                    <SelectItem value="hatchback">Хэтчбек</SelectItem>
                    <SelectItem value="wagon">Универсал</SelectItem>
                    <SelectItem value="crossover">Кроссовер</SelectItem>
                    <SelectItem value="suv">Внедорожник</SelectItem>
                  </SelectContent>
                </Select>
                <Select onValueChange={setTransmission}>
                  <SelectTrigger>
                    <SelectValue placeholder="Тип КПП" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все</SelectItem>
                    <SelectItem value="automatic">Автомат</SelectItem>
                    <SelectItem value="manual">Механическая</SelectItem>
                    <SelectItem value="cvt">Вариатор</SelectItem>
                    <SelectItem value="robot">Робот</SelectItem>
                  </SelectContent>
                </Select>
                <Select onValueChange={setDrivetrain}>
                  <SelectTrigger>
                    <SelectValue placeholder="Привод" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все</SelectItem>
                    <SelectItem value="fwd">Передний</SelectItem>
                    <SelectItem value="rwd">Задний</SelectItem>
                    <SelectItem value="awd">Полный</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full md:w-auto">
                <Search className="mr-2 h-4 w-4" /> Найти автомобиль
              </Button>
            </form>
          </CardContent>
        </Card>

        {filteredCars.length > 0 && (
          <div>
            <h3 className="text-2xl font-bold mb-4">Результаты поиска</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              {filteredCars.map((car) => (
                <Card key={car.id} className="flex flex-col">
                  <CardHeader className="p-0">
                    <Image
                      src={car.image}
                      alt={`${car.brand} ${car.model}`}
                      width={300}
                      height={200}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                  </CardHeader>
                  <CardContent className="flex-grow p-4">
                    <CardTitle className="text-lg font-semibold mb-2">{car.brand} {car.model}</CardTitle>
                    <p className="text-sm text-muted-foreground mb-2">Год: {car.year}</p>
                    <p className="font-bold text-lg mb-1">от {car.price.toLocaleString()} ₽</p>
                    <p className="text-sm text-muted-foreground">
                      В кредит от {Math.round(car.price / 60).toLocaleString()} ₽/мес.
                    </p>
                  </CardContent>
                  <CardFooter className="p-4 pt-0">
                    <Link 
                      href={`/catalog/${car.brand.toLowerCase()}/${car.model.toLowerCase()}`}
                      className="w-full"
                    >
                      <Button variant="outline" className="w-full">Подробнее</Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

