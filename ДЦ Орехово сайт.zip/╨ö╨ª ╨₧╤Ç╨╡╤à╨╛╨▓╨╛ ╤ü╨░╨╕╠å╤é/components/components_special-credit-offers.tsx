import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from 'lucide-react'

const offers = [
  {
    title: "Семейный автомобиль",
    description: "Специальная программа для семей с детьми",
    rate: "от 4.9%",
    term: "до 84 мес.",
    downPayment: "от 0%",
    highlight: "Господдержка"
  },
  {
    title: "Первый автомобиль",
    description: "Программа для покупателей первого автомобиля",
    rate: "от 8.3%",
    term: "до 60 мес.",
    downPayment: "от 10%",
    highlight: "Господдержка"
  },
  {
    title: "Быстрое решение",
    description: "Кредит по двум документам",
    rate: "от 18%",
    term: "до 84 мес.",
    downPayment: "от 20%",
    highlight: "Без подтверждения дохода"
  }
]

export default function SpecialCreditOffers() {
  return (
    <section className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Специальные предложения</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Выберите программу кредитования, которая подходит именно вам
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {offers.map((offer) => (
          <Card key={offer.title} className="relative overflow-hidden hover:shadow-lg transition-shadow">
            {offer.highlight && (
              <div className="absolute top-4 right-4 bg-primary text-white text-sm px-3 py-1 rounded-full">
                {offer.highlight}
              </div>
            )}
            <CardHeader>
              <CardTitle>{offer.title}</CardTitle>
              <p className="text-muted-foreground">{offer.description}</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Ставка</p>
                    <p className="font-semibold">{offer.rate}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Срок</p>
                    <p className="font-semibold">{offer.term}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Первый взнос</p>
                    <p className="font-semibold">{offer.downPayment}</p>
                  </div>
                </div>
                <Button className="w-full bg-primary text-white hover:bg-primary/90 group">
                  Подробнее
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}

