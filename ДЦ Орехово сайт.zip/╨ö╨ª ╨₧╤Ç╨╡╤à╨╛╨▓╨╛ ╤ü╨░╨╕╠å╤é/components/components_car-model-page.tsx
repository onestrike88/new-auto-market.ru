'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { cn } from '@/lib/utils'
import CreditForm from '@/components/credit-form'
import CarSpecifications from '@/components/car-specifications'
import CarConfigurations from '@/components/car-configurations'
import PhotoGallery from '@/components/photo-gallery'
import OtherModels from '@/components/other-models'
import SpecialOffers from '@/components/special-offers'
import { RequestForm } from '@/components/request-form'

interface ColorOption {
  id: string
  hex: string
  image: string
}

const colorOptions: ColorOption[] = [
  { id: 'yellow', hex: '#D4B95E', image: '/placeholder.svg?height=400&width=600' },
  { id: 'red', hex: '#B22222', image: '/placeholder.svg?height=400&width=600' },
  { id: 'white', hex: '#FFFFFF', image: '/placeholder.svg?height=400&width=600' },
  { id: 'silver', hex: '#C0C0C0', image: '/placeholder.svg?height=400&width=600' },
  { id: 'gray', hex: '#808080', image: '/placeholder.svg?height=400&width=600' }
]

interface CarModelPageProps {
  brand: string
  model: string
  price: number
  discount: number
  monthlyPayment: number
  images: string[]
  specifications: any
  configurations: any[]
  otherModels: any[]
}

export default function CarModelPage({
  brand,
  model,
  price,
  discount,
  monthlyPayment,
  images,
  specifications,
  configurations,
  otherModels
}: CarModelPageProps) {
  const [selectedColor, setSelectedColor] = useState<ColorOption>(colorOptions[0])
  const [openForm, setOpenForm] = useState<'credit' | 'purchase' | 'test-drive' | null>(null)

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <div className="container mx-auto px-4 py-8">
      <nav className="flex mb-4 text-sm text-gray-500" aria-label="Breadcrumb">
        <ol className="inline-flex items-center space-x-1 md:space-x-3">
          <li className="inline-flex items-center">
            <Link href="/" className="hover:text-gray-900">Главная</Link>
          </li>
          <li>
            <div className="flex items-center">
              <svg className="w-3 h-3 mx-1 text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 9 4-4-4-4"/>
              </svg>
              <Link href="/catalog" className="ml-1 hover:text-gray-900">Каталог</Link>
            </div>
          </li>
          <li aria-current="page">
            <div className="flex items-center">
              <svg className="w-3 h-3 mx-1 text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m1 9 4-4-4-4"/>
              </svg>
              <span className="ml-1 text-gray-500">{brand} {model}</span>
            </div>
          </li>
        </ol>
      </nav>

      <div className="sticky top-16 bg-white z-10 py-4 border-b mb-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">{brand} {model}</h1>
          <div className="flex space-x-4">
            <Button variant="outline" onClick={() => setOpenForm('test-drive')}>Тест-драйв</Button>
            <Button onClick={() => setOpenForm('purchase')}>Купить</Button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div>
          <div className="relative aspect-video mb-4">
            <Image 
              src={selectedColor.image} 
              alt={`${brand} ${model}`} 
              layout="fill"
              objectFit="cover"
              className="rounded-lg"
            />
          </div>
          <div className="mb-4">
            <div className="flex justify-center space-x-4">
              {colorOptions.map((color) => (
                <button
                  key={color.id}
                  onClick={() => setSelectedColor(color)}
                  className={cn(
                    "w-8 h-8 rounded-full transition-all",
                    selectedColor.id === color.id && "ring-2 ring-primary"
                  )}
                  style={{ backgroundColor: color.hex }}
                  aria-label={`Выбрать цвет ${color.id}`}
                />
              ))}
            </div>
          </div>
          <Card className="my-6">
            <CardHeader>
              <CardTitle>Стоимость автомобиля</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold mb-2">от {price.toLocaleString()} ₽</p>
              <p className="text-lg mb-4">Выгода до {discount.toLocaleString()} ₽ при покупке в кредит</p>
              <p className="text-lg mb-6">Ежемесячный платеж: от {monthlyPayment.toLocaleString()} ₽/мес.</p>
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="w-full" onClick={() => setOpenForm('credit')}>Рассчитать кредит</Button>
                <Button className="w-full" onClick={() => setOpenForm('purchase')}>Купить</Button>
              </div>
            </CardContent>
          </Card>
          <PhotoGallery images={images} brand={brand} model={model} />
        </div>
        <div>
          <CreditForm />
        </div>
      </div>

      <Tabs defaultValue="specifications" className="mb-8">
        <TabsList className="w-full justify-start mb-4">
          <TabsTrigger value="specifications">Характеристики</TabsTrigger>
          <TabsTrigger value="configurations">Комплектации</TabsTrigger>
        </TabsList>
        <TabsContent value="specifications">
          <CarSpecifications specifications={specifications} />
        </TabsContent>
        <TabsContent value="configurations">
          <CarConfigurations configurations={configurations} />
        </TabsContent>
      </Tabs>

      <OtherModels brand={brand} models={otherModels} />

      <SpecialOffers />

      <RequestForm
        isOpen={openForm !== null}
        onClose={() => setOpenForm(null)}
        formType={openForm || 'credit'}
      />
    </div>
  )
}

