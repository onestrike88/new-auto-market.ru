'use client'

import Link from 'next/link'
import { Phone, Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useState } from 'react'
import { RequestForm } from '@/components/request-form'

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [openForm, setOpenForm] = useState<'callback' | 'special-offer' | null>(null)

  const handleCallbackRequest = () => {
    setOpenForm('callback')
  }

  const handleSpecialOffer = () => {
    setOpenForm('special-offer')
  }

  const closeMobileMenu = () => {
    setMobileMenuOpen(false)
  }

  return (
    <header className="fixed top-0 left-0 right-0 bg-white shadow-md z-50">
      <div className="container mx-auto px-4 py-2 md:py-4">
        <div className="flex flex-wrap justify-between items-center">
          <Link href="/" className="text-xl md:text-2xl font-bold">ДЦ Орехово</Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="hover:text-primary">Главная</Link>
            <Link href="/catalog" className="hover:text-primary">Каталог</Link>
            <Link href="/credit" className="hover:text-primary">Кредит</Link>
            <Link href="/trade-in" className="hover:text-primary">Trade-in</Link>
            <Link href="/promotions" className="hover:text-primary">Акции</Link>
          </nav>
          <div className="flex items-center gap-2 md:gap-4">
            <div className="hidden md:flex items-center">
              <Phone className="w-4 h-4 mr-2" />
              <span>+7 (495) 495-95-95</span>
            </div>
            <div className="hidden md:block">
              <Button variant="outline" size="sm" onClick={handleCallbackRequest}>Обратный звонок</Button>
            </div>
            <div className="hidden md:block">
              <Button variant="default" size="sm" className="bg-primary text-white hover:bg-primary-dark" onClick={handleSpecialOffer}>
                Специальное предложение
              </Button>
            </div>
            <div className="md:hidden">
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
      </div>
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-md z-50">
          <nav className="flex flex-col p-4">
            <Link href="/" className="py-2 hover:text-primary" onClick={closeMobileMenu}>Главная</Link>
            <Link href="/catalog" className="py-2 hover:text-primary" onClick={closeMobileMenu}>Каталог</Link>
            <Link href="/credit" className="py-2 hover:text-primary" onClick={closeMobileMenu}>Кредит</Link>
            <Link href="/trade-in" className="py-2 hover:text-primary" onClick={closeMobileMenu}>Trade-in</Link>
            <Link href="/promotions" className="py-2 hover:text-primary" onClick={closeMobileMenu}>Акции</Link>
          </nav>
        </div>
      )}
      <RequestForm
        isOpen={openForm !== null}
        onClose={() => setOpenForm(null)}
        formType={openForm === 'callback' ? 'callback' : 'special-offer'}
      />
    </header>
  )
}

export default Header

