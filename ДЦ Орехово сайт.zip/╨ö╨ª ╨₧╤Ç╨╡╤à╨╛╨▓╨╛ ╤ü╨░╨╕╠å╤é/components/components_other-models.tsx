import Image from 'next/image'
import Link from 'next/link'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

interface OtherModelsProps {
  brand: string
  models: any[] // Replace with proper type
}

export default function OtherModels({ brand, models }: OtherModelsProps) {
  return (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold mb-4">Другие модели {brand}</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {models.map((model, index) => (
          <Card key={index}>
            <CardHeader>
              <Image src={model.image} alt={`${brand} ${model.name}`} width={200} height={150} className="rounded-lg" />
            </CardHeader>
            <CardContent>
              <CardTitle>{model.name}</CardTitle>
              <p>{model.availableCount} авто в наличии</p>
              <p>от {model.price.toLocaleString()} ₽</p>
              <p>В кредит от: {model.monthlyPayment.toLocaleString()} ₽/мес.</p>
            </CardContent>
            <CardFooter>
              <Link href={`/catalog/${brand.toLowerCase()}/${model.name.toLowerCase()}`}>
                <Button variant="outline">Подробнее</Button>
              </Link>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

