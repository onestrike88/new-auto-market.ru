import Image from 'next/image'

interface PhotoGalleryProps {
  images: string[]
  brand: string
  model: string
}

export default function PhotoGallery({ images, brand, model }: PhotoGalleryProps) {
  return (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold mb-4">Фотогалерея</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {images.map((image, index) => (
          <Image key={index} src={image} alt={`${brand} ${model} - фото ${index + 1}`} width={300} height={200} className="rounded-lg" />
        ))}
      </div>
    </div>
  )
}

