import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Star } from 'lucide-react'
import Image from 'next/image'

const testimonials = [
  {
    name: 'Иван Петров',
    rating: 5,
    date: '14 ноября 2023',
    text: 'Отличный сервис! Купил автомобиль своей мечты по выгодной цене. Рекомендую всем!',
    image: '/placeholder.svg?height=100&width=100',
    source: 'Яндекс Карты'
  },
  {
    name: 'Анна Сидорова',
    rating: 5,
    date: '2 декабря 2023',
    text: 'Очень довольна покупкой. Менеджеры помогли выбрать идеальный автомобиль для моей семьи.',
    image: '/placeholder.svg?height=100&width=100',
    source: 'Яндекс Карты'
  },
  {
    name: 'Алексей Иванов',
    rating: 4,
    date: '28 ноября 2023',
    text: 'Быстрое оформление кредита и отличные условия. Спасибо за профессионализм!',
    image: '/placeholder.svg?height=100&width=100',
    source: 'Яндекс Карты'
  }
]

export default function Testimonials() {
  return (
    <section className="bg-gray-100 py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">Отзывы наших клиентов</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white">
              <CardHeader>
                <div className="flex items-center mb-4">
                  <Image
                    src={testimonial.image}
                    alt={testimonial.name}
                    width={48}
                    height={48}
                    className="rounded-full mr-4"
                  />
                  <div>
                    <h3 className="font-semibold">{testimonial.name}</h3>
                    <div className="flex items-center">
                      <div className="flex mr-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-500">{testimonial.date}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-2">{testimonial.text}</p>
                <div className="flex items-center mt-4">
                  <Image
                    src="/placeholder.svg?height=20&width=20"
                    alt="Яндекс Карты"
                    width={20}
                    height={20}
                    className="mr-2"
                  />
                  <span className="text-sm text-gray-500">{testimonial.source}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

