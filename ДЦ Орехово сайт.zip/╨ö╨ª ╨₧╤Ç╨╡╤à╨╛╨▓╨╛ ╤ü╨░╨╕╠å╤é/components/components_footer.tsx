import Link from 'next/link'
import { Button } from '@/components/ui/button'
import Image from 'next/image'

const Footer = () => {
  return (
    <footer className="bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 px-4 md:px-0">
          <div>
            <h3 className="text-lg font-semibold mb-4">ДЦ Орехово</h3>
            <p className="text-sm">Официальный дилер. Продажа и обслуживание автомобилей в Москве.</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Контакты</h3>
            <p className="text-sm">Телефон: +7 (495) 495-95-95</p>
            <p className="text-sm">Адрес: г. Москва, Ореховый бульвар, 26</p>
            <p className="text-sm">Email: info@dc-orehovo.ru</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Навигация</h3>
            <ul className="text-sm space-y-2">
              <li><Link href="/catalog" className="hover:text-primary">Каталог</Link></li>
              <li><Link href="/credit" className="hover:text-primary">Кредит</Link></li>
              <li><Link href="/trade-in" className="hover:text-primary">Trade-in</Link></li>
              <li><Link href="/promotions" className="hover:text-primary">Акции</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Мы в соцсетях</h3>
            <div className="flex space-x-4">
              {/* Add social media icons here */}
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-200">
          <div className="flex flex-wrap justify-center items-center gap-4">
            <Image src="/placeholder.svg?height=50&width=100" alt="Trusted Partner 1" width={100} height={50} />
            <Image src="/placeholder.svg?height=50&width=100" alt="Trusted Partner 2" width={100} height={50} />
            <Image src="/placeholder.svg?height=50&width=100" alt="Trusted Partner 3" width={100} height={50} />
          </div>
          <div className="mt-6 text-center flex flex-col sm:flex-row justify-center gap-4">
            <Button variant="outline" className="mr-4">Подписаться на новости</Button>
            <Button variant="default">Связаться с нами</Button>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-gray-200 text-center text-sm">
          <p>&copy; 2023 ДЦ Орехово. Все права защищены. Лучший выбор автомобилей в Москве.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

